const { db } = require('./db');

async function getSkyport() {
  const url = await db.get('settings-skyport-url') || process.env.SKYPORT_URL || '';
  const key = await db.get('settings-skyport-key') || process.env.SKYPORT_KEY || '';
  
  // Standalone mode is enabled if URL or key is missing, or matches placeholder patterns
  const isStandalone = !url || !key || 
                        url.includes('your-skyport-instance') || 
                        url.includes('placeholder') || 
                        url.trim() === '';
                        
  return { url, key, isStandalone };
}

module.exports = { getSkyport };
