const path = require('path');
let KeyvModule = require('keyv');
let Keyv = KeyvModule.Keyv || KeyvModule.default || KeyvModule;

const dbPath = path.join(__dirname, '../storage/database.sqlite');
const db = new Keyv(`sqlite://${dbPath}`);

module.exports = { db };