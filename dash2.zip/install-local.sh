#!/usr/bin/env bash

# Exit immediately if a command exits with a non-zero status
set -e

# Define color codes for pretty output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}====================================================${NC}"
echo -e "${CYAN}          PalPod Dashboard Local Installer          ${NC}"
echo -e "${BLUE}====================================================${NC}"
echo ""

# Function to print error and exit
fail() {
    echo -e "\n${RED}[ERROR] $1${NC}"
    exit 1
}

# Function to print status
status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Function to print success
success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to print warnings
warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Step 1: Pre-flight checks (Git, Node.js, npm)
status "Checking pre-requisites..."

if ! command -v git &> /dev/null; then
    fail "Git is not installed. Please install Git and try again."
else
    success "Git is installed: $(git --version)"
fi

if ! command -v node &> /dev/null; then
    fail "Node.js is not installed. Please install Node.js (v18+) and try again."
else
    NODE_VER=$(node -v | cut -d'v' -f2)
    NODE_MAJOR=$(echo "$NODE_VER" | cut -d'.' -f1)
    if [ "$NODE_MAJOR" -lt 18 ]; then
        warn "Node.js version is $NODE_VER. Version 18 or higher is recommended."
    else
        success "Node.js is installed: v$NODE_VER"
    fi
fi

if ! command -v npm &> /dev/null; then
    fail "npm is not installed. Please install npm and try again."
else
    success "npm is installed: $(npm -v)"
fi

# Step 2: Detect package manager
status "Detecting package manager..."
PKG_MANAGER="npm"
INSTALL_CMD="npm install"
RUN_DEV_CMD="npm run dev"

if [ -f "package-lock.json" ]; then
    status "Detected package-lock.json. Preferring npm."
    PKG_MANAGER="npm"
elif [ -f "pnpm-lock.yaml" ]; then
    status "Detected pnpm-lock.yaml. Preferring pnpm."
    PKG_MANAGER="pnpm"
    INSTALL_CMD="pnpm install"
    RUN_DEV_CMD="pnpm run dev"
elif [ -f "yarn.lock" ]; then
    status "Detected yarn.lock. Preferring yarn."
    PKG_MANAGER="yarn"
    INSTALL_CMD="yarn install"
    RUN_DEV_CMD="yarn dev"
else
    # Fallback checks for commands if lockfile is missing
    if command -v pnpm &> /dev/null; then
        PKG_MANAGER="pnpm"
        INSTALL_CMD="pnpm install"
        RUN_DEV_CMD="pnpm run dev"
    elif command -v yarn &> /dev/null; then
        PKG_MANAGER="yarn"
        INSTALL_CMD="yarn install"
        RUN_DEV_CMD="yarn dev"
    fi
fi
success "Selected package manager: ${CYAN}$PKG_MANAGER${NC}"

# Step 3: Install project dependencies
status "Installing project dependencies using $PKG_MANAGER..."
if ! $INSTALL_CMD; then
    fail "Dependency installation failed."
fi
success "All dependencies successfully installed!"

# Step 4: Environment Configuration (.env)
status "Configuring environment variables..."
if [ -f ".env.example" ]; then
    if [ ! -f ".env" ]; then
        cp .env.example .env
        success "Created .env file from .env.example"
    else
        success ".env file already exists. Skipping copy."
    fi
    
    # Enforce PORT=3000 and APP_PORT=3000 inside .env file
    if grep -q "APP_PORT=" .env; then
        # Replace existing APP_PORT
        sed -i 's/^APP_PORT=.*/APP_PORT=3000/' .env || true
    else
        echo "APP_PORT=3000" >> .env
    fi

    if grep -q "PORT=" .env; then
        # Replace existing PORT
        sed -i 's/^PORT=.*/PORT=3000/' .env || true
    else
        echo "PORT=3000" >> .env
    fi
    success "Enforced Port 3000 configuration in .env file."
else
    warn ".env.example not found. Skipping environment configuration copy."
fi

# Step 5: Final preparation and verification
status "Preparing application for startup on Port 3000..."
# Verify that dash2/index.js exists
if [ ! -f "dash2/index.js" ]; then
    fail "Could not find dash2/index.js. Ensure you are running this script from the project root."
fi

# Export environment variables to guarantee they are available to Node/Express
export PORT=3000
export APP_PORT=3000

echo -e "\n${GREEN}====================================================${NC}"
echo -e "${GREEN}        Installation completed successfully!        ${NC}"
echo -e "${GREEN}====================================================${NC}"
echo ""
echo -e "Your PalPod Dashboard is ready to run."
echo -e "Local URL: ${CYAN}http://localhost:3000${NC}"
echo -e "Press ${YELLOW}Ctrl+C${NC} to stop the server once it is running."
echo ""
status "Starting the development server now..."
echo ""

# Start the dev server
exec $RUN_DEV_CMD
