const express = require('express');
const passport = require('passport');
const DiscordStrategy = require('passport-discord');
const axios = require('axios');
const fs = require('fs');
const randomstring = require("randomstring");
const router = express.Router();

const { db } = require('../function/db');
const { logError } = require('../function/logError');
const { getSkyport } = require('../function/getSkyport');

// Configure passport to use Discord
passport.use(new DiscordStrategy({
  clientID: process.env.DISCORD_CLIENT_ID,
  clientSecret: process.env.DISCORD_CLIENT_SECRET,
  callbackURL: process.env.DISCORD_CALLBACK_URL,
  scope: ['identify', 'email']
}, (accessToken, refreshToken, profile, done) => {
  return done(null, profile);
}));

// Serialize and deserialize user
passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((user, done) => {
  done(null, user);
});

// Skyport account system
async function checkAccount(email, username, id) {
  const skyport = await getSkyport();
  
  if (skyport.isStandalone) {
    console.log("Operating checkAccount in Standalone Mode. Creating local mapping for user:", email);
    await db.set(`id-${email}`, id || username || 'local_user');
    await db.set(`password-${email}`, 'standalone_password_not_needed');
    return;
  }

  try {
    // Check if user already exists in Skyport
    let response;
    try {
      response = await axios.post(`${skyport.url}/api/getUser`, {
        type: 'email',
        value: email
      }, {
        headers: {
          'x-api-key': skyport.key,
          'Content-Type': 'application/json'
        }
      });

      // User already exists, log and return
      console.log('User already exists in Skyport. User ID:', response.data.userId);
      await db.set(`id-${email}`, response.data.userId);
      return;
    } catch (err) {
      if (err.response && err.response.status !== 404) {
        logError('Failed to check user existence in Skyport', err);
        throw err;
      }
    }

    // Generate a random password for new user
    const password = randomstring.generate({ length: process.env.PASSWORD_LENGTH });

    // Create user in Skyport
    try {
      response = await axios.post(`${skyport.url}/api/auth/create-user`, {
        username,
        email,
        password,
        userId: id
      }, {
        headers: {
          'x-api-key': skyport.key,
          'Content-Type': 'application/json'
        }
      });

      // Log creation and set password in database
      await db.set(`password-${email}`, password);
      await db.set(`id-${email}`, response.data.userId);
      logError('User created in Skyport');
    } catch (err) {
      if (err.response && err.response.status === 409) {
        console.log('User creation conflict: User already exists in Skyport.');
      } else {
        logError('Failed to create user in Skyport', err);
        throw err;
      }
    }
  } catch (error) {
    logError('Error during account check', error);
    throw error;
  }
}

// Discord login route
router.get('/login/discord', passport.authenticate('discord'));

// Discord callback route
router.get('/callback/discord', passport.authenticate('discord', {
  failureRedirect: '/login'
}), (req, res) => {
  checkAccount(req.user.email, req.user.username, req.user.id)
    .then(() => res.redirect(req.session.returnTo || '/dashboard'))
    .catch(error => {
      logError('Error during account check', error);
      res.redirect('/dashboard');
    });
});

// Logout route
router.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      logError('Logout failed', err);
      return res.redirect('/');
    }
    res.redirect('/');
  });
});

// Local Registration Page
router.get('/register', (req, res) => {
  if (req.isAuthenticated()) {
    return res.redirect('/dashboard');
  }
  res.render('register', {
    req: req,
    name: process.env.APP_NAME || "PalPod",
    user: req.user
  });
});

// Local Registration POST
router.post('/register', async (req, res) => {
  const { fullName, username, email, password, confirmPassword } = req.body;

  if (!fullName || !username || !email || !password || !confirmPassword) {
    return res.redirect('/register?err=MISSINGPARAMS');
  }

  if (password !== confirmPassword) {
    return res.redirect('/register?err=PASSWORDMISMATCH');
  }

  const cleanUsername = username.trim().toLowerCase();
  const cleanEmail = email.trim().toLowerCase();

  if (!/^[a-zA-Z0-9_]{3,20}$/.test(cleanUsername)) {
    return res.redirect('/register?err=INVALIDUSERNAME');
  }

  // Check if user already exists
  const existingUserByEmail = await db.get(`user-email-${cleanEmail}`);
  const existingEmailByUsername = await db.get(`user-username-${cleanUsername}`);

  if (existingUserByEmail || existingEmailByUsername) {
    return res.redirect('/register?err=USEREXISTS');
  }

  // Save in SQLite database using Keyv
  const userObj = {
    fullName,
    username: cleanUsername,
    email: cleanEmail,
    password, // Store password
    id: cleanUsername // Username as unique ID
  };

  await db.set(`user-email-${cleanEmail}`, userObj);
  await db.set(`user-username-${cleanUsername}`, cleanEmail);

  res.redirect('/?success=REGISTERED');
});

// Local Login POST
router.post('/login', async (req, res) => {
  const { emailOrUsername, password } = req.body;

  if (!emailOrUsername || !password) {
    return res.redirect('/?err=MISSINGPARAMS');
  }

  const inputVal = emailOrUsername.trim().toLowerCase();

  // 1. Check for Admin Credentials
  if ((inputVal === 'admin' || inputVal === 'admin@gmail.com') && password === 'admin') {
    // Set admin flag in Keyv
    await db.set(`admin-admin@gmail.com`, true);
    // Ensure standard resources/coins exist so they can use the dashboard
    if (!(await db.get(`coins-admin@gmail.com`))) {
      await db.set(`coins-admin@gmail.com`, 1000.00);
    }
    
    const adminUser = {
      id: 'admin',
      username: 'admin',
      email: 'admin@gmail.com',
      avatar: '0',
      fullName: 'Administrator'
    };

    req.login(adminUser, (err) => {
      if (err) {
        console.error("Admin login failed:", err);
        return res.redirect('/?err=INTERNALERROR');
      }
      return res.redirect('/admin');
    });
    return;
  }

  // 2. Normal Local User Check
  let userEmail = inputVal;
  const resolvedEmail = await db.get(`user-username-${inputVal}`);
  if (resolvedEmail) {
    userEmail = resolvedEmail;
  }

  const userObj = await db.get(`user-email-${userEmail}`);
  if (!userObj || userObj.password !== password) {
    return res.redirect('/?err=BADCREDENTIALS');
  }

  const normalUser = {
    id: userObj.username,
    username: userObj.username,
    email: userObj.email,
    avatar: '0',
    fullName: userObj.fullName
  };

  req.login(normalUser, (err) => {
    if (err) {
      console.error("Local login failed:", err);
      return res.redirect('/?err=INTERNALERROR');
    }
    return res.redirect('/dashboard');
  });
});

// GET /login redirects to /
router.get('/login', (req, res) => {
  res.redirect('/');
});

module.exports = router;
