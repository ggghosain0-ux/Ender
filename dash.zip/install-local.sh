#!/usr/bin/env bash

# Exit immediately if a command exits with a non-zero status
set -e

# Define color codes for pretty output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}====================================================${NC}"
echo -e "${CYAN}          PalPod Dashboard Local Installer          ${NC}"
echo -e "${BLUE}====================================================${NC}"
echo ""

# Function to print error and exit
fail() {
    echo -e "\n${RED}[ERROR] $1${NC}"
    exit 1
}

# Function to print status
status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Function to print success
success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to print warnings
warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Step 1: Pre-flight checks (Git & Node.js)
status "Checking pre-requisites..."

if ! command -v git &> /dev/null; then
    fail "Git is not installed. Please install Git and try again."
else
    success "Git is installed: $(git --version)"
fi

if ! command -v node &> /dev/null; then
    fail "Node.js is not installed. Please install Node.js (v18+) and try again."
else
    NODE_VER=$(node -v | cut -d'v' -f2)
    NODE_MAJOR=$(echo "$NODE_VER" | cut -d'.' -f1)
    if [ "$NODE_MAJOR" -lt 18 ]; then
        warn "Node.js version is $NODE_VER. Version 18 or higher is recommended."
    else
        success "Node.js is installed: v$NODE_VER"
    fi
fi

# Step 2: Detect package manager
status "Detecting package manager..."
PKG_MANAGER="npm"
INSTALL_CMD="npm install"
RUN_DEV_CMD="npm run dev"

if [ -f "package-lock.json" ]; then
    status "Detected package-lock.json. Preferring npm."
    PKG_MANAGER="npm"
elif [ -f "pnpm-lock.yaml" ]; then
    status "Detected pnpm-lock.yaml. Preferring pnpm."
    PKG_MANAGER="pnpm"
    INSTALL_CMD="pnpm install"
    RUN_DEV_CMD="pnpm run dev"
elif [ -f "yarn.lock" ]; then
    status "Detected yarn.lock. Preferring yarn."
    PKG_MANAGER="yarn"
    INSTALL_CMD="yarn install"
    RUN_DEV_CMD="yarn dev"
else
    # Fallback checks for commands if lockfile is missing
    if command -v pnpm &> /dev/null; then
        PKG_MANAGER="pnpm"
        INSTALL_CMD="pnpm install"
        RUN_DEV_CMD="pnpm run dev"
    elif command -v yarn &> /dev/null; then
        PKG_MANAGER="yarn"
        INSTALL_CMD="yarn install"
        RUN_DEV_CMD="yarn dev"
    fi
fi
success "Selected package manager: ${CYAN}$PKG_MANAGER${NC}"

# Step 3: Install project dependencies
status "Installing project dependencies using $PKG_MANAGER..."
if ! $INSTALL_CMD; then
    fail "Dependency installation failed."
fi
success "All dependencies successfully installed!"

# Step 4: Environment Configuration (.env)
status "Configuring environment variables..."
if [ -f ".env.example" ]; then
    if [ ! -f ".env" ]; then
        cp .env.example .env
        success "Created .env file from .env.example"
        warn "Please remember to open the .env file and fill in your actual Discord OAuth and Skyport API credentials."
    else
        success ".env file already exists. Skipping creation."
    fi
else
    warn ".env.example not found. Skipping environment configuration copy."
fi

# Step 5: Final preparation and verification
status "Preparing application for startup..."
# Verify that dash2/index.js exists
if [ ! -f "dash2/index.js" ]; then
    fail "Could not find dash2/index.js. Ensure you are running this script from the project root."
fi

# Retrieve configured port if available, default to 3000
PORT=3000
if [ -f ".env" ]; then
    ENV_PORT=$(grep -E "^APP_PORT=" .env | cut -d'=' -f2 | tr -d '\r' | tr -d '"' | tr -d "'")
    if [ ! -z "$ENV_PORT" ]; then
        PORT=$ENV_PORT
    fi
fi

echo -e "\n${GREEN}====================================================${NC}"
echo -e "${GREEN}        Installation completed successfully!        ${NC}"
echo -e "${GREEN}====================================================${NC}"
echo ""
echo -e "Your PalPod Dashboard is ready to run."
echo -e "Local URL: ${CYAN}http://localhost:$PORT${NC}"
echo -e "Press ${YELLOW}Ctrl+C${NC} to stop the server once it is running."
echo ""
status "Starting the development server now..."
echo ""

# Start the dev server
exec $RUN_DEV_CMD
